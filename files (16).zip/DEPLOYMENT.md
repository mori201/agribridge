# AgriBridge — Guide de déploiement

Architecture cible pour un test rapide et gratuit (voir [ARCHITECTURE.md](./ARCHITECTURE.md) §5) : frontend sur **Vercel**, backend sur **Render**, base de données sur **Neon**, cache sur **Upstash**, stockage documentaire sur **Cloudflare R2** ou **AWS S3**. Fonctionne aussi entièrement en local (voir le README, section Démarrage rapide).

Ce document décrit le chemin recommandé (plateformes managées, zéro conteneur à opérer) et une alternative Docker pour qui préfère self-hoster.

## 0. Avant de déployer

- [ ] `npm run db:migrate` lancé au moins une fois en local pour générer `apps/backend/prisma/migrations/` (absent de ce dépôt — voir la note technique du README) — **committez ce dossier**.
- [ ] Secrets de production générés (`JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET` — 32 caractères minimum, différents de ceux du `.env.example`, jamais réutilisés entre environnements).
- [ ] Tests E2E exécutés contre une base de test à jour (voir README, section Tests).

## 1. Base de données — Neon (PostgreSQL)

1. Créer un projet sur [neon.tech](https://neon.tech).
2. Copier la chaîne de connexion (« Connection string », mode *pooled* recommandé pour une API avec beaucoup de connexions courtes).
3. Depuis votre machine locale (accès réseau normal aux moteurs Prisma) :
   ```bash
   DATABASE_URL="<chaîne Neon>" npx prisma migrate deploy --schema=apps/backend/prisma/schema.prisma
   ```
4. Optionnel — jeu de données de démonstration :
   ```bash
   DATABASE_URL="<chaîne Neon>" npm run db:seed --workspace=apps/backend
   ```
   Ne jamais lancer le seed sur une base contenant déjà des données réelles (comptes de démonstration à mot de passe connu).

## 2. Cache — Upstash (Redis)

1. Créer une base Redis sur [upstash.com](https://upstash.com) (région proche de votre backend).
2. Copier l'URL de connexion (`REDIS_URL`, format `rediss://...` — TLS activé par défaut chez Upstash, compatible avec `ioredis` sans configuration additionnelle).

## 3. Stockage documentaire — Cloudflare R2 (ou AWS S3)

1. Créer un bucket (ex. `agribridge-documents-prod`).
2. Générer des identifiants d'accès scoped à ce bucket uniquement (jamais des identifiants de compte complets).
3. Variables à renseigner sur le backend : `STORAGE_PROVIDER=r2` (ou `s3`), `STORAGE_ENDPOINT` (R2 : `https://<account_id>.r2.cloudflarestorage.com`), `STORAGE_REGION`, `STORAGE_BUCKET`, `STORAGE_ACCESS_KEY_ID`, `STORAGE_SECRET_ACCESS_KEY`, `STORAGE_FORCE_PATH_STYLE=false`.
4. Activer le chiffrement au repos côté fournisseur (SSE) — voir [SECURITY.md](./SECURITY.md) §5.

## 4. Backend — Render (gratuit, sans carte) ou Railway (payant depuis 2026)

> **Mise à jour** : Railway n'offre plus de palier gratuit exploitable — carte bancaire obligatoire dès l'inscription, facturation à l'usage avec un plancher réel autour de 5 $/mois. **Render reste gratuit sans carte pour un usage de test** : un service web gratuit, avec une limite connue — il se met en veille après 15 minutes d'inactivité et met 30-60 secondes à redémarrer au prochain appel. Sans enjeu pour tester une MVP ; à garder en tête si vous montrez la démo en direct (le premier chargement peut sembler lent). Pour un backend qui reste réactif en continu, palier payant Render à partir de 7 $/mois.

**Déploiement Render (recommandé pour les tests) :**
1. [render.com](https://render.com) → New → Web Service → connecter le dépôt GitHub.
2. Root Directory : racine du monorepo (laisser vide) — nécessaire pour que `npm install` résolve les workspaces.
3. Runtime : Node. Build Command et Start Command : voir ci-dessous (communes aux deux plateformes).
4. Health Check Path : `/health`.
5. Free tier : aucune carte requise pour ce chemin.

**Configuration commune aux deux plateformes :**
- Commande d'installation/build :
  ```bash
  npm install && npx prisma generate --schema=apps/backend/prisma/schema.prisma && npm run build --workspace=apps/backend
  ```
- Commande de démarrage :
  ```bash
  node apps/backend/dist/main.js
  ```
- Port : la plateforme fournit `PORT` automatiquement — le code le lit déjà (`process.env.PORT`, voir `main.ts`).
- Health check : `GET /health` (exclu du préfixe `/api/v1`, voir `main.ts`) — à renseigner dans les réglages de la plateforme pour un redémarrage automatique en cas de panne.

**Variables d'environnement à renseigner** (voir `.env.example` pour la liste complète) : `DATABASE_URL` (Neon), `REDIS_URL` (Upstash), `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`, `APP_URL` (URL du frontend déployé — utilisée pour CORS), `STORAGE_*` (R2/S3), et selon les besoins `NOTIFY_SMS_PROVIDER`/`TWILIO_*`, `NOTIFY_EMAIL_PROVIDER`/`SMTP_*`, `AI_PROVIDER`/`AI_API_KEY`.

Après le premier déploiement, appliquer les migrations contre la base de production (voir §1) — aucune de ces plateformes ne le fait automatiquement.

## 5. Frontend — Vercel

1. Importer le dépôt sur [vercel.com](https://vercel.com), répertoire racine du projet : `apps/frontend` (réglage « Root Directory » dans les paramètres du projet Vercel).
2. Vercel détecte Next.js automatiquement — aucune commande de build à renseigner.
3. Variable d'environnement : `NEXT_PUBLIC_API_URL` = URL publique du backend déployé (§4), suffixée de `/api/v1`.
4. Une fois déployé, mettre à jour `APP_URL` côté backend (§4) avec l'URL Vercel finale, pour que CORS autorise le frontend à appeler l'API.

## 6. Alternative — Docker

Pour un self-hosting (VPS, Fly.io) plutôt que des plateformes managées. `apps/backend/Dockerfile` et `apps/frontend/Dockerfile` sont fournis, tous deux à construire **depuis la racine du monorepo** (obligatoire pour que npm workspaces résolve les dépendances) :

```bash
docker build -f apps/backend/Dockerfile  -t agribridge-backend .
docker build -f apps/frontend/Dockerfile -t agribridge-frontend \
  --build-arg NEXT_PUBLIC_API_URL=https://votre-api.example.com/api/v1 .

docker run -p 4000:4000 --env-file apps/backend/.env agribridge-backend
docker run -p 3000:3000 agribridge-frontend
```

`docker-compose.yml` (racine du dépôt) reste réservé à l'infrastructure de développement local (Postgres/Redis/MinIO/ClamAV) — il ne lance pas les applications elles-mêmes ; les Dockerfiles ci-dessus sont le chemin de production.

## 7. Après déploiement

- [ ] `GET https://votre-api.example.com/health` répond `{"status":"ok","database":"ok"}`.
- [ ] Inscription + connexion testées de bout en bout sur les URLs de production.
- [ ] `POST /organizations/:id/verify` et `POST /opportunities/:id/verify` testés avec un compte `ADMIN` réel (créé manuellement en base — l'inscription publique ne permet que `PRODUCER`/`FUNDER`, voir `docs/API.md`).
- [ ] Si l'antivirus (`ANTIVIRUS_ENABLED=true`) est activé, un service ClamAV atteignable depuis le backend est déployé séparément — non couvert par les plateformes ci-dessus, voir [SECURITY.md](./SECURITY.md) §3.
